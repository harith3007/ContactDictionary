void options();//shows options on the screen
void clear();//clear the screen
int admin();//for admin credentials
void admin_menu();//shows menu for the admin
int user_reg();
int user_login();
void user_menu();
int pass_reset();
void add_new_contact();
int val_name();
int val_mobileno();
int val_emailid();
int val_emergencycontact();
void delete_personal();
void delete_business();
void delete_contact();
//void update_contact_options();
void update_personal();
void update_business();
void display_contact_options();
void List_all_personal_contacts();
void List_all_business_contacts();

