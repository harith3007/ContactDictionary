#include<stdlib.h>
void clear()
{
	system("clear");
}
