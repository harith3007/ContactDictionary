#include<functions.h>
#include<stdlib.h>
#include<stdio.h>
int main()
{
	printf("\n\n\n\n\n\n\t\tWELCOME TO CONTACT MANAGEMENT SYSTEM");
	options();
	return EXIT_SUCCESS;
}
